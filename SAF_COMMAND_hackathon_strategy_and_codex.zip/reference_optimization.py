"""Reference demonstration optimiser for SAF Command.
Simplifications: screened candidates are observed biomass locations; capacity at refinery is biomass-input throughput; straight-line geographic distances; no OpEx except provided tonne-km rates; one-period, undiscounted capex; arbitrary illustrative SAF demands and yield. NOT a real-world feasibility study.
"""
import csv,json,math,sys,time
from pathlib import Path
from collections import defaultdict
import numpy as np,pandas as pd
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
BASE_DIR=Path(__file__).resolve().parent
SUPPLY_PATH=BASE_DIR/'kalimantan_80_locations_6800kt_full_range.csv'
AIRPORT_PATH=BASE_DIR/'airports.dat'
S=pd.read_csv(SUPPLY_PATH)
C={}
with open(AIRPORT_PATH,encoding='utf-8',errors='replace') as f:
 for row in csv.reader(f):
  if row[4] in ['PNK','PKN','BPN','TRK'] and row[3]=='Indonesia':
   C[row[4]]={'code':row[4], 'name':row[1], 'lat':float(row[6]),'lon':float(row[7])}
assert len(C)==4
AIRPORTS=[C[k] for k in ['PNK','PKN','BPN','TRK']]
def hav(a,b):
 lat1,lon1=np.radians([a[0],a[1]]);lat2,lon2=np.radians([b[0],b[1]])
 dlat=lat2-lat1;dlon=lon2-lon1
 return 6371*2*np.arctan2(np.sqrt(np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2),np.sqrt(1-(np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2)))
# Candidate screen: from each observed district, choose highest output farm and a point nearest coordinate median.
depts=[];refs=[]
for group,sub in S.groupby(['province','district']):
 center=np.array([sub.latitude.median(),sub.longitude.median()]);near=(sub[['latitude','longitude']].values-center)**2
 center_site=sub.iloc[np.argmin(near.sum(axis=1))]
 peak=sub.sort_values('production_kilotons',ascending=False).iloc[0]
 for site in [center_site,peak]:
  if site.location_id not in depts: depts.append(site.location_id)
 refs.append(center_site.location_id)
D=S.set_index('location_id').loc[depts].reset_index();R=S.set_index('location_id').loc[refs].reset_index()
print('screened depots',len(D),'refineries',len(R),flush=True)

def solve(demand={'PNK':60,'PKN':30,'BPN':90,'TRK':30},yield_rate=.20,time_limit=50):
 n,m,k,a=len(S),len(D),len(R),4
 sections={};count=0
 for name,sz in [('FD',n*m),('DR',m*k),('RA',k*a),('DB',m*2),('RB',k*2)]:
  sections[name]=slice(count,count+sz);count+=sz
 costs=np.zeros(count);lbs=np.zeros(count);ubs=np.full(count,np.inf);integers=np.zeros(count,dtype=int)
 df=sections['DB'];rf=sections['RB'];integers[df]=1;integers[rf]=1;ubs[df]=1;ubs[rf]=1
 costs[df]=np.tile([2.25,4.5],m);costs[rf]=np.tile([480,765],k)
 distFD=np.array([[hav([s.latitude,s.longitude],[d.latitude,d.longitude]) for d in D.itertuples()] for s in S.itertuples()])
 distDR=np.array([[hav([d.latitude,d.longitude],[r.latitude,r.longitude]) for r in R.itertuples()] for d in D.itertuples()])
 distRA=np.array([[hav([r.latitude,r.longitude],[airport['lat'],airport['lon']]) for airport in AIRPORTS] for r in R.itertuples()])
 # flow units: kilotons, c: millions USD, rate USD per tonne per km -> multiply by .001
 costs[sections['FD']]=(.1*.001*distFD).ravel();costs[sections['DR']]=(.12*.001*distDR).ravel();costs[sections['RA']]=(.08*.001*distRA).ravel()
 rr=[];cc=[];vv=[];lo=[];up=[]
 def add(items,l=-np.inf,u=np.inf):
  row=len(lo);lo.append(l);up.append(u)
  for ix,val in items:
   if val!=0:rr.append(row);cc.append(ix);vv.append(val)
 def ixF(i,j):return sections['FD'].start+i*m+j
 def ixM(j,h):return sections['DR'].start+j*k+h
 def ixO(h,q):return sections['RA'].start+h*a+q
 def ixD(j,t):return sections['DB'].start+j*2+t
 def ixR(h,t):return sections['RB'].start+h*2+t
 for i,s in enumerate(S.itertuples()):add([(ixF(i,j),1) for j in range(m)],u=s.production_kilotons)
 for j in range(m):
  add([(ixF(i,j),1) for i in range(n)]+[(ixM(j,h),-1) for h in range(k)],l=0,u=0)
  add([(ixF(i,j),1) for i in range(n)]+[(ixD(j,0),-150),(ixD(j,1),-300)],u=0)
  add([(ixD(j,t),1) for t in range(2)],u=1)
 for h in range(k):
  add([(ixM(j,h),1) for j in range(m)]+[(ixO(h,q),-1/yield_rate) for q in range(a)],l=0,u=0)
  add([(ixM(j,h),1) for j in range(m)]+[(ixR(h,0),-500),(ixR(h,1),-1087)],u=0)
  add([(ixR(h,t),1) for t in range(2)],u=1)
 for q,air in enumerate(AIRPORTS):add([(ixO(h,q),1) for h in range(k)],l=demand[air['code']],u=demand[air['code']])
 mat=coo_matrix((vv,(rr,cc)),shape=(len(lo),count)).tocsr()
 start=time.monotonic()
 res=milp(c=costs,integrality=integers,bounds=Bounds(lbs,ubs),constraints=LinearConstraint(mat,np.array(lo),np.array(up)),options={'time_limit':time_limit,'mip_rel_gap':0.02})
 if res.x is None:
  return {'status':str(res.message),'gap':None,'solve_seconds':round(time.monotonic()-start,2)}
 x=res.x
 fac_depot=[];fac_ref=[];flow=[]
 for j,d in D.iterrows():
  for t,size in enumerate(['Small','Large']):
   if x[ixD(j,t)]>.5:fac_depot.append({'id':d.location_id,'district':d.district,'size':size,'lat':float(d.latitude),'lon':float(d.longitude),'inflow_kt':round(sum(x[ixF(i,j)] for i in range(n)),2)})
 for h,r in R.iterrows():
  for t,size in enumerate(['Small','Large']):
   if x[ixR(h,t)]>.5:fac_ref.append({'id':r.location_id,'district':r.district,'size':size,'lat':float(r.latitude),'lon':float(r.longitude),'inflow_kt':round(sum(x[ixM(j,h)] for j in range(m)),2)})
 for h in range(k):
  for q in range(a):
   if x[ixO(h,q)]>.001:flow.append({'from_refinery':R.iloc[h].location_id,'airport':AIRPORTS[q]['code'],'saf_kt':round(float(x[ixO(h,q)]),3)})
 costs_each={'capex_MUSD':float(costs[df]@x[df]+costs[rf]@x[rf]),'farm_to_depot_MUSD':float(costs[sections['FD']]@x[sections['FD']]),'depot_to_refinery_MUSD':float(costs[sections['DR']]@x[sections['DR']]),'refinery_to_airport_MUSD':float(costs[sections['RA']]@x[sections['RA']])}
 return {'status':str(res.message),'optimality_gap':None if getattr(res,'mip_gap',None) is None else round(float(res.mip_gap),4),'solve_seconds':round(time.monotonic()-start,2),'demand_saf_kt':demand,'conversion_yield':yield_rate,'total_cost_MUSD':round(float(res.fun),3),'costs_MUSD':{k:round(v,3) for k,v in costs_each.items()},'depots':fac_depot,'refineries':fac_ref,'refinery_to_airport_flow':flow,'method':'MILP with SciPy/HiGHS; great-circle distance proxy; scenario assumptions; candidate sites limited to screened biomass locations; no road feasibility; no refinery operating costs or annuitization'}

if __name__=='__main__':
 ans=solve();print(json.dumps(ans,indent=2));open(BASE_DIR/'reference_scenario.json','w').write(json.dumps(ans,indent=2))
