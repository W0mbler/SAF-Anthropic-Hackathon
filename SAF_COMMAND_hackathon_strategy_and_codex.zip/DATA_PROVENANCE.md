# Dataset provenance and licensing

- `kalimantan_80_locations_6800kt_full_range.csv`: user-uploaded challenge biomass dataset, 80 locations, 6,800 kt, 7 fields. Hackathon organiser-provided; its public redistribution rights have NOT been verified.
- `airports.dat`: user-uploaded aviation location database, used to extract only PNK, PKN, BPN and TRK. This file resembles OpenFlights data; OpenFlights databases have ODbL/database-content licensing terms (https://openflights.org/data). Review the exact source and licence before redistributing or releasing derivatives.
- `reference_optimization.py`: proof-of-concept MILP on 13 screened depot and 8 screened refinery candidate points selected from observed biomass coordinates. Uses great-circle distances, illustrative fuel demand, 20% assumed mass yield, no additional processing OpEx, upfront facility capex plus one transport period; results are not verified road routes or permitted industrial sites.
- `reference_scenario.json`, `reference_sensitivity.json`: calculated, illustrative outputs only, not real airport demand or certified fuel economics.

Do not publish claims of real-world optimal physical construction plans or verified emission savings from these demonstration outputs.
