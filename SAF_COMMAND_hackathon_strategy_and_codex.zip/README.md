# SAF COMMAND

**From biomass to boarding gates. Every decision optimised.**

SAF Command is a geospatial, optimisation-first decision cockpit for planning sustainable aviation fuel (SAF) supply infrastructure across Kalimantan. It evaluates candidate preprocessing depots, SAF refineries, and material flows to four airports, and supports interactive scenario comparison.

> **Project status:** This README is a submission-ready specification for the proposed full-stack application. It does not claim that the full-stack implementation exists yet. A functioning, limited-reference MILP model and its illustrative results are available separately as `reference_optimization.py`, `reference_scenario.json`, and `reference_sensitivity.json`.

## Problem statement

Kalimantan's biomass is dispersed across 80 locations. A viable regional SAF supply chain requires coordinated investment in depots and refineries, feedstock allocation, and transport to Supadio (PNK), Iskandar (PKN), Sultan Aji Muhamad Sulaiman (BPN), and Juwata (TRK). Picking each decision independently can create unnecessary infrastructure and logistics costs.

## Solution overview

SAF Command combines (1) uploaded geospatial biomass and airport data, (2) a transparent mixed-integer linear program for facility location, sizing, and three-echelon material flows, (3) interactive scenario comparison and visual network exploration, and (4) optional AI explanations grounded strictly in verified solver output.

## Feature set

- **Supply Atlas:** Inspect 80 biomass locations and four airports; filter and inspect source records.
- **Network Optimiser:** Choose small/large depots and refineries; allocate flows; display facility coordinates, utilisation, and cost decomposition.
- **Scenario Studio:** Change airport SAF demand, conversion yield, distance assumptions, project horizon, and facility availability; rerun optimisation.
- **Decision Comparison:** Compare competing solved scenarios, including facility additions/removals, demand service, upfront investment, and recurring logistics costs.
- **Explain the Decision:** Plain-language deterministic explanations, with optional OpenAI-powered narratives using strictly validated solver facts.
- **Export:** Download scenario JSON and a stakeholder-friendly CSV report.
- **Guest Demo:** A usable, locally functional read/write demo without mandatory sign-in.

## Model and assumptions

| Item | Demo default | Source / status |
|---|---|---|
| Supply locations | 80, aggregate 6,800 kilotonnes | Challenge CSV |
| Airport scope | PNK, PKN, BPN, TRK | Challenge / OpenFlights |
| Airport demand (PNK/PKN/BPN/TRK) | 60/30/90/30 kt SAF | **Illustrative, not observed** |
| Biomass-to-SAF mass yield | 20% | **Illustrative, not an engineering guarantee** |
| Refinery capacities | 500 kt small / 1,087 kt large | Challenge; **assumed biomass-input capacity** |
| Depot capacities | 150 kt small / 300 kt large | Challenge |
| Depot CapEx | US$2.25M small / US$4.5M large | Challenge |
| Refinery CapEx | US$480M small / US$765M large | Challenge |
| Farm → depot transport | US$0.10/tonne-km | Challenge |
| Depot → refinery transport | US$0.12/tonne-km | Challenge |
| Refinery → airport transport | US$0.08/tonne-km | Challenge |
| Distance mode | Great-circle distance, labelled **proxy** | No road matrix provided |
| Processing OpEx | US$0 unless user supplies value | Missing from challenge |
| Financial horizon | 1 model period, no discounting | Demo assumption |
| Site feasibility | Candidate coordinate screen, **not permitted construction land** | Engineering/site diligence required |

All flows are conserved in physical units. Raw biomass need not all be consumed: 6,800 kt is available potential, not mandatory throughput. Distances are never presented as verified road routes unless a validated road-distance matrix is supplied. Any renewable fuel sustainability or lifecycle-carbon claim requires separate feedstock provenance and certified lifecycle analysis.

### Optimisation objective

For horizon `H` and discount rate `r`, minimise:

`upfront_facility_capex + PVAF(H,r) * (annual_transport_cost + annual_processing_opex)`

where `PVAF(H,r) = H` for `r=0`, otherwise `[1-(1+r)^(-H)]/r`.

Subject to available biomass, depot and refinery input capacities, mutually exclusive small/large size at each site, biomass mass conservation, SAF conversion yield, and exact airport demand satisfaction. Facilities and flows are jointly optimised. The MIP solver's status, time limit, relative optimality gap and input assumptions must be shown.

### Preliminary reference result

A screened 13-depot/8-refinery-candidate MILP with the illustrative 210 kt SAF demand and 20% yield selected **one large refinery and five depots**, for an estimated **US$800.989M** one-period modelled cost (US$780.75M CapEx and US$20.239M transportation). It served all four airport demands; reported MIP gap 1.48%. This is a candidate-constrained mathematical result, not a verified physical infrastructure plan. A 260 kt higher-demand scenario required one large and one small refinery in the reference model. Do not turn these example numbers into business savings claims without a defined, solved baseline.

## Architecture

```mermaid
flowchart LR
  U[Browser: Next.js + MapLibre] --> API[FastAPI REST API]
  API --> DB[(PostgreSQL)]
  API --> MIP[SciPy MILP / HiGHS]
  API --> EX[Explanation service]
  EX --> AI[Optional OpenAI API]
  MIP --> API
  DB --> API
```

**Separation of concerns:** The mathematical solver alone determines facility and flow decisions. AI only summarises validated outputs. A deterministic fallback works when no AI API key is present.

## Technical stack

- **Frontend:** Next.js App Router, TypeScript, Tailwind CSS, MapLibre GL JS, deck.gl, Recharts and TanStack Query.
- **Backend:** Python 3.12, FastAPI, Pydantic v2, SQLAlchemy 2, SciPy `optimize.milp`, NumPy, Pandas, Alembic.
- **Database:** PostgreSQL 16 for scenarios, users, solver runs, facilities and flows.
- **Authentication:** Guest/demo session plus optional email/password login with Argon2 password hashing, secure HttpOnly session cookies and per-owner authorisation.
- **AI:** Optional server-side OpenAI Responses API; structured, strictly bounded fact input; deterministic fallback if unavailable.
- **Deployment:** Docker Compose for local/demo, compatible with a Docker-capable cloud host. No external map API key should be required to render a useful local fallback map.
- **Tests:** Pytest backend, Vitest frontend utilities/components, Playwright smoke test, GitHub Actions CI.

## Recommended repository structure

```text
saf-command/
├── apps/
│   └── web/
│       ├── app/
│       ├── components/
│       ├── lib/
│       ├── tests/
│       ├── package.json
│       └── Dockerfile
├── services/
│   └── api/
│       ├── app/
│       │   ├── api/
│       │   ├── auth/
│       │   ├── db/
│       │   ├── ingest/
│       │   ├── optimization/
│       │   ├── explanations/
│       │   └── main.py
│       ├── migrations/
│       ├── tests/
│       ├── pyproject.toml
│       └── Dockerfile
├── data/
│   ├── airports_selected.csv
│   ├── biomass_locations.csv
│   └── DATA_PROVENANCE.md
├── scripts/
├── .github/workflows/ci.yml
├── .env.example
├── compose.yaml
├── README.md
└── LICENSE
```

## Installation and running locally

Requirements: Docker Engine and Docker Compose plugin; or Node.js LTS, Python 3.12 and PostgreSQL 16 for manual development.

```bash
cd saf-command
cp .env.example .env
docker compose up --build
```

The generated application must provide database migration and seed scripts that run automatically or via a documented command. Open `http://localhost:3000` for the UI and `http://localhost:8000/docs` for the OpenAPI documentation.

## Environment variables

```dotenv
DATABASE_URL=postgresql+psycopg://saf:saf@db:5432/safcommand
NEXT_PUBLIC_API_URL=http://localhost:8000
SESSION_SECRET=replace_with_random_secret_before_deployment
OPENAI_API_KEY=
OPENAI_MODEL=
SOLVER_TIME_LIMIT_SECONDS=20
SOLVER_RELATIVE_GAP=0.02
ALLOWED_ORIGINS=http://localhost:3000
APP_ENV=development
```

Configure a strong unique session secret in production, change PostgreSQL credentials, enable HTTPS, and never commit production secrets. The AI integration is optional and should not block the demo when no key is present.

## API overview

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Liveness/ready status |
| GET | `/api/v1/locations` | 80 biomass and 4 airport records |
| GET | `/api/v1/candidates` | Candidate site coordinates and eligibility |
| POST | `/api/v1/scenarios` | Create scenario from validated assumptions |
| GET | `/api/v1/scenarios` | List the user's or guest session's scenarios |
| GET | `/api/v1/scenarios/{id}` | Retrieve scenario and its runs |
| POST | `/api/v1/scenarios/{id}/solve` | Execute bounded MIP and persist result |
| GET | `/api/v1/runs/{id}` | Solver status, gap, costs, facilities, flows |
| POST | `/api/v1/compare` | Compare two owned solver runs |
| POST | `/api/v1/runs/{id}/explain` | Deterministic or optional AI explanation |
| GET | `/api/v1/runs/{id}/export` | Export JSON or CSV |
| POST | `/api/v1/auth/register` | Optional account creation |
| POST | `/api/v1/auth/login` | Optional authenticated session |
| POST | `/api/v1/auth/logout` | Revoke session |

## AI components

The optional explanation endpoint sends a compact schema of validated run facts (cost components, capacities, scenario deltas, solution status, modelling caveats) to the configured model. It requests a summary that distinguishes facts from assumptions. No LLM-generated number may overwrite a solver value. If no AI key is configured, use fixed, tested explanation templates.

## Security and reliability

- Pydantic schema validation, scenario bounds and finite-number checks.
- Per-owner / guest-session access controls; CSRF protection for cookie-auth mutations.
- Password hashing using Argon2 and secure HttpOnly cookies.
- API rate limiting, bounded solve time, memory-safe data parsing and sanitised errors.
- No arbitrary user Python execution and no secrets in browser bundles.
- Do not send personally identifiable, private business or proprietary feedstock data to AI providers without explicit user consent.
- Rerunnable migrations, health checks, structured logs and tested failure states.

## Deployment

For a hackathon, run the full system with Docker Compose on a single Docker-compatible host and use HTTPS through a reverse proxy for any public endpoint. For longer-term production, add managed PostgreSQL, worker isolation/queuing if demand warrants, backups, monitoring, disaster recovery and secret management. Check map tile usage policies before public deployment.

## Screenshots

To add after the application is implemented:
- `docs/screenshots/supply-atlas.png` — initial 80-point Kalimantan map.
- `docs/screenshots/optimized-network.png` — facility and flow solution.
- `docs/screenshots/scenario-compare.png` — cost and network comparison.

## Demo video

A 2-minute product walkthrough should show the baseline solve, an increase in airport demand, a second solve, and an explanation of new facility investments. Add the final public video URL when published.

## Innovation highlights

1. Joint facility siting, sizing and material-flow optimisation.
2. Conversion-aware biomass-to-SAF mass balances rather than mixing feedstock and fuel tonnes.
3. Candidate-site transparency, solution gaps and exact data-provenance labels.
4. Live scenario changes that are recomputed, not visually hardcoded.
5. Explainable mathematical decisions with optional, constrained AI narration.

## Future roadmap

- Verified OpenStreetMap road routing and transfer feasibility, with multimodal river/road transport.
- Detailed lifecycle/NPV economics and plant-specific conversion pathways.
- Facility siting exclusion layers, land status, protected areas and permitting checks.
- Feedstock seasonality, storage, resilience and multi-period expansion decisions.
- Carbon lifecycle analysis from approved and traceable inputs; certification workflow integration.
- Data integrations and enterprise collaboration.

## Team contributions

Recommended accountable areas: **optimisation and data**, **API and database**, **frontend/geospatial UX**, **product, research and demo**. Publish the actual names and verified work of contributors after team allocation; do not invent credits.

## Licensing and data provenance

The recommended code license is **MIT**. This does **not** automatically license the challenge's biomass data or the airport database. The original `airports.dat` resembles OpenFlights data; OpenFlights publishes its databases under the **Open Database License (ODbL)** with attribution and applicable share-alike obligations. Retain provenance and comply with the precise source dataset licence before public redistribution. Treat the hackathon-supplied biomass CSV as organiser-provided data with unknown redistribution permissions until confirmed; do not assume it is MIT-licensed.

Primary references: IATA SAF production and bottlenecks; ICAO CORSIA eligible fuels; Indonesia DGCA/ICAO 2025 aviation climate action plan; OpenFlights database licence; HiGHS solver; MapLibre GL; NASA Space Apps 2025 winner archive (comparative inspiration, not a claim of this challenge's judging rubric).

**Disclaimer:** SAF Command makes conditional planning recommendations only. It does not validate site ownership, roads, environmental approvals, operational fuel quality, sustainability certification or real demand without additional data.
