# MASTER CODEX IMPLEMENTATION PROMPT

You are the lead engineer, product designer, operations-research specialist, DevOps engineer and QA owner for SAF COMMAND. Build an actual, runnable, coherent, tested full-stack application in the CURRENT working directory. You have never seen any prior context; everything necessary for the implementation is written here, including the full 80-location source data below. Do not return a plan instead of implementation. Create all files, write working code, run commands, fix build/test failures, and present only truthful verification results at the end.

## Mission and judging criteria

Create the highest-quality feasible hackathon submission for this challenge: "How might we optimise the Sustainable Aviation Fuel (SAF) supply chain in Kalimantan?" The submission MUST jointly decide facility coordinates from permitted candidate sites, small/large depot and refinery sizes, and flows from farms to depots, depots to refineries and refineries to four airports; minimise costs subject to supply, capacity, conversion and airport demand. Make the result inspectable on an excellent, usable geographic dashboard. The goal is an undeniable live demo rather than a static dashboard or invented result.

Product name: **SAF COMMAND**. Tagline: **From biomass to boarding gates. Every decision optimised.** Primary users: SAF project developers, investors, energy planners, airline fuel procurement teams, government agencies. This is a planning-support product, NOT certification of feasible routes, fuel quality, construction permits or certified environmental impacts.

## Nonnegotiable implementation rules

1. Deliver a fully runnable real application with frontend, backend, database, session-based authentication, genuine mathematical MILP solver, optional real AI integration, Docker Compose, CI, migrations, docs and meaningful automated tests.
2. No pseudo-code, static mock results, unimplemented action buttons, dead navigations, fake API responses, artificial demo animations pretending to be solver results, hardcoded facility solutions, empty functions, TODO comments, `pass` stubs, or code omitted with ellipses.
3. The app MUST work end-to-end with no external AI key, no paid GIS key and no pre-existing user account. AI is optional; deterministic explanations are required and sufficient for offline demo.
4. Do not call an LLM to solve facility location, determine quantities, calculate money or verify physical feasibility. SciPy MILP/HiGHS does those calculations. An LLM may only explain immutable, validated facts returned by the solver.
5. The supplied scenario data do not include real airport demand, biomass-to-SAF conversion efficiency, processing OpEx, project lifetime, verified road distances, siting legal eligibility or lifecycle emissions. Every default not from the challenge MUST be marked "illustrative assumption" across UI, API, README and exports. Never claim certified fuel, CO2 reductions, real roads or validated investment projections.
6. Solve all four airports PNK, PKN, BPN and TRK — never include other airports. Cleanly distinguish physical biomASS kt from final SAF kt. Use geographic coordinate order [longitude, latitude] for GeoJSON/MapLibre and [latitude, longitude] for geodesic calculation.
7. Keep production deployment honest. No publicly accessible default credentials. Rate-limit and owner-scope user actions. Sessions must be secure, guest mode must be safely isolated and AI key must never reach the browser.
8. Prioritise completion in this order: (a) truthful working seeded data + solver, (b) map/results/scenarios, (c) reliability/auth/tests/packaging, (d) optional AI and animations. If time is limited, do not sacrifice core correctness to add decorative features.
9. Generate all configurations and dependency manifests. The repository must boot with `cp .env.example .env && docker compose up --build` and show a working seed scenario, allowing solve and rerun. Where a command fails, fix it; report unexecuted checks explicitly rather than claiming they passed.
10. Use a permissive MIT license for YOUR SOURCE CODE only. User-supplied challenge CSV redistribution rights are unknown; keep source provenance and licence caution; airport data resembles OpenFlights (ODbL). Do not claim third-party data are MIT-licensed.

## Provided exact challenge economics

Facility capital cost and nominal input-throughput capacity:
- Small preprocessing depot: US$2,250,000; 150 kilotonnes.
- Large preprocessing depot: US$4,500,000; 300 kilotonnes.
- Small SAF refinery: US$480,000,000; 500 kilotonnes.
- Large SAF refinery: US$765,000,000; 1,087 kilotonnes.
- For modelling, assume depot and refinery capacities are **biomass-input kt per model period**. State clearly that the refinery interpretation is an assumption because the problem sheet is ambiguous.

Transport: farm→depot US$0.10 per tonne/km, depot→refinery US$0.12 per tonne/km, refinery→airport US$0.08 per tonne/km. Each stage provides small and large truck options at identical per-tonne/km prices, with capacities respectively: farm→depot 3 t or 9 t; depot→refinery 18 t or 30 t; refinery→airport 16 t or 32 t. Therefore truck capacity does not change transport cost in THIS formulation. Optionally show estimated truckloads/trips as `ceil(tonnes / truck_capacity_tonnes)` but NEVER claim truck-size cost savings without additional per-trip assumptions. Preserve this nuance in README/UI and tests.

Supply: 80 locations, precisely 6,800 kilotonnes in aggregate. Demand file is NOT supplied. **The user must be able to edit demand by airport.** Default illustrative scenario: PNK 60, PKN 30, BPN 90, TRK 30 **kt SAF per model period**, total 210 kt. Biomass-to-SAF mass yield default **0.20**, a user-editable illustrative value in range (0,1]. Biomass is available supply, not mandatory total collected quantity. Set processing OpEx to 0 until user enters a real value and clearly label cost coverage incomplete.

Airports, exact coordinates from provided airports.dat (IATA, latitude, longitude):
- PNK, Supadio Airport, -0.15071099996566772, 109.40399932861328
- PKN, Iskandar Airport, -2.70519995689, 111.672996521
- BPN, Sultan Aji Muhamad Sulaiman Airport, -1.26827001572, 116.893997192
- TRK, Juwata Airport, 3.326667, 117.569444

### Full exact biomass source dataset

This is the complete CSV originally supplied for the challenge. Parse it as data, preserve identifiers and all 7 fields, verify 80 rows and total `production_kilotons==6800` within numeric tolerance. Place it in a clearly labelled import fixture / seed asset, and document source provenance. Do not introduce synthetic points when the full data are already available here.

```csv
location_id,province,district,production_kilotons,production_tonnes,latitude,longitude
KAL_SUP_01,West Kalimantan,Ketapang,90.12,90120,-1.9635,110.1136
KAL_SUP_02,Central Kalimantan,Kotawaringin Barat,96.6,96600,-2.1083,111.5801
KAL_SUP_03,West Kalimantan,Ketapang,96.44,96440,-2.0515,109.9553
KAL_SUP_04,East Kalimantan,Paser,99.22,99220,-1.6149,116.3117
KAL_SUP_05,Central Kalimantan,Kotawaringin Timur,90.46,90460,-2.085,113.235
KAL_SUP_06,West Kalimantan,Ketapang,87.91,87910,-1.847,110.0258
KAL_SUP_07,West Kalimantan,Ketapang,89.06,89060,-2.0294,110.3472
KAL_SUP_08,West Kalimantan,Sanggau,94.0,94000,0.2911,110.6932
KAL_SUP_09,Central Kalimantan,Kotawaringin Barat,26.33,26330,-2.264,111.7926
KAL_SUP_10,East Kalimantan,Kutai Kartanegara,99.51,99510,-0.6682,116.8524
KAL_SUP_11,East Kalimantan,Kutai Kartanegara,92.16,92160,-0.664,117.3125
KAL_SUP_12,Central Kalimantan,Kotawaringin Timur,93.8,93800,-2.7613,112.8714
KAL_SUP_13,East Kalimantan,Kutai Kartanegara,92.81,92810,-0.3066,116.8705
KAL_SUP_14,West Kalimantan,Ketapang,29.34,29340,-2.1397,110.2164
KAL_SUP_15,West Kalimantan,Ketapang,88.32,88320,-1.682,110.4027
KAL_SUP_16,Central Kalimantan,Kotawaringin Timur,98.25,98250,-2.5858,112.7929
KAL_SUP_17,East Kalimantan,Kutai Kartanegara,88.27,88270,-0.3747,116.804
KAL_SUP_18,North Kalimantan,Bulungan,92.89,92890,2.61,117.2423
KAL_SUP_19,Central Kalimantan,Kotawaringin Timur,99.71,99710,-2.5394,112.8334
KAL_SUP_20,Central Kalimantan,Kotawaringin Barat,34.1,34100,-2.9999,111.9992
KAL_SUP_21,East Kalimantan,Paser,90.65,90650,-2.1934,115.7592
KAL_SUP_22,West Kalimantan,Ketapang,89.0,89000,-1.5194,109.602
KAL_SUP_23,West Kalimantan,Sanggau,92.52,92520,-0.0962,110.4256
KAL_SUP_24,East Kalimantan,Paser,96.52,96520,-1.8548,116.1854
KAL_SUP_25,West Kalimantan,Sanggau,88.0,88000,0.3297,110.817
KAL_SUP_26,South Kalimantan,Tanah Laut,93.86,93860,-4.0801,114.8675
KAL_SUP_27,Central Kalimantan,Kotawaringin Barat,93.25,93250,-1.9857,111.856
KAL_SUP_28,Central Kalimantan,Kotawaringin Barat,88.6,88600,-2.3295,111.9558
KAL_SUP_29,West Kalimantan,Ketapang,88.41,88410,-1.6332,110.1275
KAL_SUP_30,East Kalimantan,Kutai Kartanegara,99.81,99810,-0.3435,117.0175
KAL_SUP_31,West Kalimantan,Ketapang,96.65,96650,-1.6977,109.6352
KAL_SUP_32,West Kalimantan,Ketapang,92.04,92040,-1.6782,109.7887
KAL_SUP_33,Central Kalimantan,Kotawaringin Timur,96.69,96690,-2.6368,112.6695
KAL_SUP_34,West Kalimantan,Sanggau,87.84,87840,0.2514,110.2592
KAL_SUP_35,West Kalimantan,Ketapang,99.9,99900,-1.6283,110.2045
KAL_SUP_36,Central Kalimantan,Kotawaringin Timur,91.25,91250,-2.5737,112.6033
KAL_SUP_37,West Kalimantan,Ketapang,97.19,97190,-2.0081,109.8869
KAL_SUP_38,East Kalimantan,Kutai Kartanegara,23.62,23620,-0.3295,117.0183
KAL_SUP_39,West Kalimantan,Sanggau,95.76,95760,0.2131,110.645
KAL_SUP_40,West Kalimantan,Sanggau,22.84,22840,-0.2488,110.4914
KAL_SUP_41,West Kalimantan,Ketapang,91.08,91080,-1.7119,110.0077
KAL_SUP_42,West Kalimantan,Sanggau,88.76,88760,0.133,110.3271
KAL_SUP_43,West Kalimantan,Ketapang,87.96,87960,-1.6746,109.7672
KAL_SUP_44,East Kalimantan,Kutai Kartanegara,91.87,91870,-0.3668,116.8975
KAL_SUP_45,Central Kalimantan,Kotawaringin Timur,94.55,94550,-2.0425,113.0427
KAL_SUP_46,West Kalimantan,Sanggau,96.19,96190,0.2625,110.7212
KAL_SUP_47,Central Kalimantan,Kotawaringin Timur,88.6,88600,-2.4623,113.0832
KAL_SUP_48,West Kalimantan,Ketapang,88.95,88950,-1.6378,110.0902
KAL_SUP_49,Central Kalimantan,Kotawaringin Barat,94.09,94090,-2.6715,111.589
KAL_SUP_50,West Kalimantan,Ketapang,90.03,90030,-2.1621,109.9169
KAL_SUP_51,West Kalimantan,Ketapang,93.01,93010,-1.9542,110.0706
KAL_SUP_52,East Kalimantan,Paser,90.57,90570,-1.5392,115.8861
KAL_SUP_53,West Kalimantan,Sanggau,91.7,91700,0.2589,110.3311
KAL_SUP_54,East Kalimantan,Kutai Kartanegara,92.83,92830,-0.712,116.982
KAL_SUP_55,East Kalimantan,Kutai Kartanegara,89.76,89760,-0.4098,116.5264
KAL_SUP_56,East Kalimantan,Paser,89.47,89470,-2.2348,115.7677
KAL_SUP_57,East Kalimantan,Kutai Kartanegara,25.07,25070,-0.0881,116.8219
KAL_SUP_58,West Kalimantan,Ketapang,96.97,96970,-1.8634,109.8828
KAL_SUP_59,South Kalimantan,Tanah Laut,87.72,87720,-3.9454,114.676
KAL_SUP_60,South Kalimantan,Tanah Laut,93.13,93130,-3.5655,114.8385
KAL_SUP_61,East Kalimantan,Paser,89.76,89760,-2.0292,116.2806
KAL_SUP_62,West Kalimantan,Ketapang,96.05,96050,-1.6347,109.7354
KAL_SUP_63,West Kalimantan,Sanggau,92.73,92730,0.4711,110.978
KAL_SUP_64,Central Kalimantan,Kotawaringin Barat,89.4,89400,-2.6729,112.0284
KAL_SUP_65,Central Kalimantan,Kotawaringin Barat,88.1,88100,-2.5395,111.7025
KAL_SUP_66,East Kalimantan,Kutai Kartanegara,98.64,98640,-0.3758,117.121
KAL_SUP_67,Central Kalimantan,Kotawaringin Barat,89.3,89300,-2.6718,111.704
KAL_SUP_68,Central Kalimantan,Kotawaringin Barat,35.94,35940,-2.7388,111.3012
KAL_SUP_69,West Kalimantan,Ketapang,30.99,30990,-2.1443,110.0022
KAL_SUP_70,North Kalimantan,Bulungan,96.08,96080,2.8936,117.2919
KAL_SUP_71,Central Kalimantan,Kotawaringin Timur,93.87,93870,-2.4114,112.9518
KAL_SUP_72,Central Kalimantan,Kotawaringin Timur,99.42,99420,-2.2989,113.0191
KAL_SUP_73,West Kalimantan,Sanggau,99.03,99030,-0.2772,110.5956
KAL_SUP_74,West Kalimantan,Sanggau,99.61,99610,0.2713,111.0006
KAL_SUP_75,West Kalimantan,Sanggau,93.87,93870,0.1668,110.9547
KAL_SUP_76,Central Kalimantan,Kotawaringin Barat,27.79,27790,-2.214,111.9176
KAL_SUP_77,East Kalimantan,Kutai Kartanegara,91.32,91320,-0.7849,117.0677
KAL_SUP_78,Central Kalimantan,Kotawaringin Barat,97.14,97140,-2.3248,111.4876
KAL_SUP_79,Central Kalimantan,Kotawaringin Barat,32.55,32550,-2.5115,112.0284
KAL_SUP_80,West Kalimantan,Ketapang,92.4,92400,-2.1498,109.7591
```

## Product features, stories and acceptance criteria

**P0 / MUST HAVE:**
- Guest demo landing/dashboard without signup; visible branded header, scenario selector, assumption badge, big interactive Kalimantan map and KPI strip (available biomass, modelled SAF demand, selected facilities, total modelled cost, solution state/gap).
- Supply Atlas with exactly 80 biomass points and the four airports; click points to inspect IDs, capacities, coordinates, province/district; filters by province and legend toggles for sources/airports/depots/refineries/flows.
- Scenario Editor with editable demand per airport, yield, project horizon in positive integer years (default=1), nonnegative discount rate (default=0), optional annual processing OpEx by refinery size (default 0), cost/distance sensitivity multiplier (default 1.0 with an honest "distance approximation" label), and site-availability exclusions; allow named save, duplicate and rerun. Show clear validation errors and explain assumed quantities.
- Joint MILP optimise action that returns feasible/optimal, time-limited-incumbent, or infeasible statuses; never render invented results. Return and render exact chosen candidate sites, size, [lat,lon], installed capacity, allocated throughput, utilisation, and all three flow stages and quantities.
- Genuine, inspectable cost breakdown: upfront depot/refinery CapEx, annual transport per stage, annual fixed processing OpEx, total `CapEx + discounted recurring costs`, per-airport delivery figures, MIP gap, solve time, distance method and assumptions. No fake "savings" without a separately computed feasible comparison.
- Map overlays: source markers, airport markers, chosen facility markers differentiated by size and type, flow lines with width proportional to calculated quantity; detail drawer opened by click; accessible contrast; smooth but not fictitious loading state.
- Scenario Compare: run two solves with different demand/yield or disabling a candidate site, display side-by-side costs, facility count, delta and changed locations; correctly explain if the objective changes because a different horizon is used.
- Deterministic Explain Decision: short natural language answer using strict computed facts: solution cost, material volumes, facility counts, key assumption caveats; optionally compare two runs. Response to unsolved/infeasible run must be truthful.
- Downloads: CSV of facilities and material flows; JSON of solver results, inputs and assumptions; ensure downloadable data numerically match visible KPIs.
- Real data ingestion on API startup with repeatable idempotent seed. Four airports only. Postgres persistence for scenarios, runs, facilities, flows. Demo can operate without sign-in.
- Basic account creation, log in/log out, current user endpoint, and per-user persisted scenarios. Demo guest data must not be readable as another user's private data.

**P1 / SHOULD HAVE, only after all P0 tests pass:**
- One-click demand presets (160 kt lower, 210 kt default, 260 kt higher with explicit per-airport splits).
- Facility-closure scenario toggles and robust unmet-demand/infeasibility diagnostics.
- Optional OpenAI-generated explanation with structured, constrained solver facts, sanitised outputs, timeout handling and deterministic fallback.
- Responsive split-pane layout and polished animations that never imply an optimisation is finished before the server returns.
- Small simulator help article: what MILP, CapEx, yield, MIP gap and straight-line distance mean.

**P2 / NICE TO HAVE — do not build until P0/P1 complete:**
- Road distance import from validated OSM/OSRM matrix with forbidden unreachable arcs; optional route polylines ONLY where verified; no public OSRM demo-server dependency.
- Sensitivity tornado chart and multi-horizon finance comparisons.
- Enterprise collaboration and audit trails.

**Core acceptance cases:**
A. Seed API returns 80 supply sources, aggregate 6,800 kt, exactly PNK/PKN/BPN/TRK airports; all coordinate values valid.
B. Given the illustrative 210 kt scenario at 20% yield, the solver serves exactly 60/30/90/30 kt SAF and uses exactly 1,050 kt biomass; no facility over capacity, no individual farm over availability; no negative flows.
C. Given the higher demand preset PNK70, PKN40, BPN110, TRK40 =260 kt, solution must find sufficient refinery throughput and serve all four demands; with 20% yield biomass throughput equals 1,300 kt.
D. A deliberately impossible demand (greater than total possible feedstock at yield) must return a proper infeasible/validation state, without showing a fake solution.
E. A candidate site exclusion cannot be selected by a new solve; the solution should change or report infeasibility truthfully.
F. Changing assumption values re-solves on the server; saved run results are immutable and reproducible.
G. The unauthenticated demo works, authenticated user scenario access is isolated, and authentication errors never expose password hashes or tokens.
H. Unit tests independently recompute all mass and cost constraints to verify solver response; end-to-end tests click `Optimise Network`, confirm KPIs/map/results, change demand and solve again.

## Exact optimisation design

Use SciPy's `scipy.optimize.milp` backed by HiGHS (or highspy with the same verified formulation), sparse matrices and bounded solver time (default 20 s), target relative MIP gap <=0.02. Implement a true mathematically defined mixed-integer linear program, not heuristics standing in for MILP. When status is time-limited with a valid feasible incumbent, show `feasible — gap not closed` with the actual reported gap; on no feasible incumbent, show no solution. Test status transitions.

**Candidate generation, deterministic and reproducible:** group the 80 biomass locations by `(province,district)` (8 such groups). For depots, select the location closest in squared lat/lon distance to its group's coordinate median AND the location with the group's maximum production; remove duplicate IDs, yielding 13 depot candidates for this exact dataset. For refineries, use just each group's median-nearest location, yielding 8 refinery candidates. Preserve all 80 sources as supply origins. The candidate sites are observed geographic reference points only, not screened permitted industrial land. Report that the solver achieves the optimum/feasible incumbent only over this chosen candidate set, not all continuous Kalimantan coordinates. If candidate generation yields other counts, verify the selection/handling of pandas ties before trusting results.

Variables, using kt as physical flow unit:
- `x[i,j] >= 0`: biomass source i to depot candidate j (kt biomass).
- `y[j,k] >= 0`: depot j to refinery k (kt biomass).
- `z[k,a] >= 0`: refinery k to airport a (kt finished SAF).
- `depot_open[j,small|large]` and `refinery_open[k,small|large]`: binary.

Constraints:
1. `sum_j x[i,j] <= source_supply[i]` for each biomass source.
2. `sum_i x[i,j] == sum_k y[j,k]` at each depot (no material loss, explicitly a demo assumption).
3. `sum_i x[i,j] <= 150 * depot_open[j,small] + 300 * depot_open[j,large]` for each depot.
4. `depot_open[j,small] + depot_open[j,large] <= 1` for every depot candidate.
5. `sum_j y[j,k] == (sum_a z[k,a]) / conversion_yield` for each refinery, with constant user-supplied yield fixed during solve.
6. `sum_j y[j,k] <= 500 * refinery_open[k,small] + 1087 * refinery_open[k,large]` for each refinery.
7. `refinery_open[k,small] + refinery_open[k,large] <= 1` for each refinery candidate.
8. `sum_k z[k,a] == airport_demand[a]` for each of the 4 airports.
9. Unavailable candidates have both open binaries fixed at zero. Flow and bounds nonnegative.
10. If future validated route adjacency is imported, disallow unreachable arcs rather than falling back silently to Haversine.

Objective in USD, with planning horizon `H`, discount rate `r`, and per-period annual recurring costs:
`min total_capex + PVAF(H,r) * (transport_leg_1 + transport_leg_2 + transport_leg_3 + processing_opex)`.
`PVAF=H` if r=0 else `(1-(1+r)**(-H))/r`.
CapEx per active facility uses the exact challenge figures. Transport cost uses physical tonnes (`kt * 1000`), per-tonne-km stage tariffs, and `distance_km`. Flow `z` is final SAF kt, not biomass kt. Optional processing OpEx is user-supplied USD/tonne of refinery biomass throughput OR explicit fixed annual USD per opened refinery size, documented unambiguously. Both default zero due missing challenge information. This is not an energy-balanced process engineering model; it is a declared mass-yield approximation.

For distances, calculate haversine great-circle kilometres (6371 km mean radius) between site coordinate pairs, then multiply by user distance factor (default 1.0). The UI must prominently say "straight-line distance proxy — not verified truck route." Use MapLibre lines as **schematic supply connections**, not navigable paths. Validate and report every cost coefficient, all flows and solution costs consistently. Use sparse matrix indexing with explicit tests for accidental row/column swaps. Persist solve provenance: solver version, input hash, candidate screen algorithm version, distance method, PVAF, gap, time-limit, and process time.

The supplied reference Python experiment achieved an illustrative modelled cost around US$800.989M (US$780.75M capex, 1.321M farm→depot, 10.613M depot→refinery, 8.304M refinery→airport) for the 210kt scenario and candidate screen above, relative gap ~1.48%. This is a verification target within reasonable solver tolerances, NOT a result to hardcode. Another observed reference scenario: 260kt demand, one large + one small refinery, cost about US$1,280.822M, same simplifications. If differences occur, inspect mathematical assumptions instead of forcing a matching number.

## Technology and full architecture

- **Frontend:** Next.js (App Router) + TypeScript + Tailwind CSS + TanStack Query + MapLibre GL JS for map + deck.gl for weighted connections if feasible + Recharts for deterministic finance graphics + Lucide icons; use reusable accessible UI primitives. Keep map functional without a paid key; use an OSM-compatible tile source with correct attribution and fallback when network fails; DO NOT overuse a public tile service.
- **Backend:** Python 3.12, FastAPI, Pydantic 2, SQLAlchemy 2, Alembic, NumPy, Pandas, SciPy `optimize.milp`; define routes and services cleanly. OpenAPI served at `/docs`.
- **Persistence:** PostgreSQL 16 in Docker Compose; UUID primary keys; normalized facilities and flows. Scenario assumptions and run snapshots immutable after solving.
- **Auth:** Argon2 password hashing, secure signed session cookies (HttpOnly, Secure in production, SameSite=Lax), explicit CSRF defense for cookie-authenticated mutations, owner checks on all scenario/run/export endpoints. Add a scoped anonymous guest session with server-issued random ID in signed HttpOnly cookie; guest save/solve/export supported, no default username/password required. Login/register/logout/me endpoints. Restrict production CORS.
- **AI:** Server-side optional OpenAI Responses API. Model comes from `OPENAI_MODEL` environment variable; do not guess that any specific model exists in the user's account. If API key/model are missing or provider fails, use complete deterministic summary generation. Send only strongly typed run facts and assumptions, never private user identifiers or raw credentials. JSON schema/validated response, no open-ended tool calls, no ability to override results; privacy notice and opt-in before sending scenario data externally.
- **Infrastructure:** `compose.yaml` with web, api and db services, healthchecks, dependency ordering, persistent database volume; multi-stage Dockerfiles for Next.js standalone production output and Python API. Include `.env.example` free of real secrets, migrations + seed on initial startup, `.gitignore`, scripts. Optional reverse proxy configuration for production TLS. No external service is required for local demo or core solve.
- **CI/CD:** GitHub Actions run backend lint/type checks/pytest and frontend lint/typecheck/unit tests/build, optionally Docker build smoke. No bogus badges until actual checks pass. Provide deployment instructions for any Docker-capable cloud platform; do not invent a hosted URL.
- **Monitoring:** Structured request logs with request IDs and solve metrics, `/health` with database check; avoid storing session secrets or private AI payloads in logs.

### Database schema (implement with SQLAlchemy + Alembic)

`users`: UUID id PK, unique email, password_hash, display_name optional, created_at.
`guest_sessions`: UUID id PK, opaque_session_hash, expiry_at, created_at; or equally secure server-side demo ownership mechanism.
`locations`: string id PK, enum kind [biomass,airport], display_name, province nullable, district nullable, iata_code nullable unique for airports, latitude double, longitude double, production_kilotons numeric nullable, source_label, created_at.
`candidate_sites`: UUID id PK or deterministic name, FK source_location_id, boolean allows_depot, boolean allows_refinery, screening_method_version, excluded_default false, created_at.
`scenarios`: UUID id PK, user_id FK nullable, guest_session_id FK nullable, name, demand_json validated map of exactly 4 airport codes, conversion_yield decimal, horizon_years integer, discount_rate decimal, distance_multiplier decimal, processing_opex_json, excluded_candidate_ids JSON, version integer, created_at, updated_at. Ownership CHECK ensures exactly one principal.
`optimization_runs`: UUID id PK, scenario_id FK, immutable input_snapshot_json, sha256_input_hash, solver_status, feasible boolean, objective_usd nullable, capex_usd nullable, recurring_transport_usd nullable, recurring_processing_usd nullable, discounted_recurring_usd nullable, relative_gap nullable, duration_ms, solver_version, distance_method, candidate_method, feasibility_note nullable, created_at.
`run_facilities`: UUID id PK, optimization_run_id FK, candidate_site_id FK, facility_type enum [depot,refinery], size enum [small,large], latitude, longitude, capacity_input_kt, throughput_input_kt, capex_usd.
`run_flows`: UUID id PK, optimization_run_id FK, stage enum [farm_depot,depot_refinery,refinery_airport], from_node_id, to_node_id, quantity_kt, material enum [biomass,SAF], distance_km, tariff_usd_per_tonne_km, one_period_transport_usd.
Use indexes on run/scenario ownership and foreign keys. If the first-run database is empty, seed data idempotently. Enforce ownership before joining runs and exports.

### API endpoints (typed OpenAPI and real response schemas)

- `GET /health`: status and db health without secrets.
- `GET /api/v1/locations`: arrays or GeoJSON with 80 sources and 4 airports, filters validated.
- `GET /api/v1/candidates`: lists of depot and refinery candidate site IDs, coordinates and screening method.
- `POST /api/v1/scenarios`, `GET /api/v1/scenarios`, `GET /api/v1/scenarios/{id}`, `PATCH /api/v1/scenarios/{id}`, `POST /api/v1/scenarios/{id}/duplicate`, `DELETE /api/v1/scenarios/{id}`: owner-scoped CRUD, validate and version edits; do not mutate existing run snapshots.
- `POST /api/v1/scenarios/{id}/solve`: run bounded MILP; return full response with run_id, solver status, gap, costs, facilities, flows, warnings and assumptions. Server timeout should exceed configured MIP timeout and produce structured failure on cutoff. Given small candidate set, synchronous solving is acceptable; serialize bounded solve concurrency if needed.
- `GET /api/v1/runs/{id}`: immutable saved result. Owner check.
- `POST /api/v1/compare`: two owned run UUIDs, returns exact deltas and changed facilities; reject incompatible units or clearly label differences in scenario horizons.
- `POST /api/v1/runs/{id}/explain`: deterministic output or optional AI output if opted-in/available; never returns fabricated model metrics.
- `GET /api/v1/runs/{id}/export?format=json|csv`: download actual results and inputs.
- `POST /api/v1/auth/register`, `POST /api/v1/auth/login`, `POST /api/v1/auth/logout`, `GET /api/v1/auth/me`: real cookie-based auth endpoints.
Use appropriate 400/401/403/404/409/422/429/500 HTTP statuses with stable error codes, human-readable UI messages and no raw traceback leakage.

### Frontend pages and design specifications

Color: deep navy/slate background, teal/emerald for biomass/fuel and restrained amber for decisions/warnings. Strong typographic hierarchy, high contrast, no visual clutter. Visually polished "energy infrastructure command centre", not generic default admin dashboard. Responsive minimum 360px; desktop first for live judging. Use skeleton placeholders while API solves and disable duplicate solve submissions. Make all chart values sourced from API response.

Routes:
- `/` **Overview / Command Centre**: top navigation (Atlas, Optimise, Compare, About), hero concise challenge statement, large interactive map ~65% width desktop / full width mobile, right-side scenario controls, top KPI cards, run status. "Optimise Network" primary CTA. First load may show selected seed run or "Ready to optimise"; never show a completed solution without backed run.
- `/atlas` **Supply Atlas**: full map, biomass dots sized by production, only four airports, province/district filter, legend and data quality/status info, summary table, feature popup.
- `/optimize` **Scenario Studio**: inputs in collapsible left panel, solve CTA, dominant map, selected facilities and costs, tabbed stage flow tables, facilities table, solver method/assumptions drawer, solution status/error state.
- `/compare` **Scenario Compare**: two run dropdowns, calculated delta cards, side-by-side map or layer switcher, changed sites table, production/transport/CapEx breakdown; meaningful empty state until two runs exist.
- `/about` **How It Works**: explanation of flow stages, data provenance, yield, model constraints, missing inputs, proxy road distances, certification disclaimer.
- `/login` and `/register` **Account**: accessible forms, clear validation, guest mode link.

Components: `AppShell`, `MapCanvas`, `SupplyLayer`, `FlowLayer`, `FacilityMarker`, `ScenarioEditor`, `DemandInputs`, `CostSummary`, `SolutionStatus`, `AssumptionNotice`, `FacilityTable`, `FlowTable`, `RunSelector`, `ComparisonPanel`, `ExplainPanel`, `AuthForm`, `ExportMenu`, `ErrorPanel`.

State behavior for each page: first-load skeleton, no-data state with actionable next step, loading solve state, infeasible solve state with recommendation to adjust assumptions, failed network state with retry, empty map tile fallback with usable spatial points on a simple bounded canvas. Input keyboard accessible, tooltips labels, reduced-motion support, readable legends.

Important UX clarity:
- Mark default numbers as **Illustrative**.
- Always distinguish `Biomass input (kt)` from `Finished SAF output (kt)`.
- Show `Network model uses straight-line distance proxy; displayed lines are not verified roads` near map.
- Show `Modelled cost excludes unspecified production OpEx unless configured` near cost KPI.
- Show relative MIP gap and candidate-set limitation.
- Only say "optimal" if solver status supports it; otherwise say "feasible incumbent" and show gap.
- Do NOT map direct farm-to-airport arcs or leave out depot→refinery stage.

## Concrete user journeys

1. Guest opens `/optimize`. The app loads real dataset, four airports, demand defaults PNK60 PKN30 BPN90 TRK30, yield20%, candidate count. User clicks optimise. App invokes API/MILP, result map and tables show one genuine solution. User inspects a refinery and discovers its size and inbound kt. User clicks download JSON; file matches backend run.
2. User changes demand to PNK70 PKN40 BPN110 TRK40, names "Higher demand", solves. Comparison identifies capacity additions and cost increase, with all KPI values from the two run records. A judge sees facility network and cost differences.
3. User disables a chosen refinery candidate and resolves; chosen site must disappear or valid infeasibility appear. No stale cached answer.
4. User asks "Why did refinery costs increase?" Deterministic service constructs explanation using actual capacity, selected plants and changed demand. If AI is configured, structured response may improve phrasing but not numbers.
5. User registers and logs in, saves a scenario, logs out; another account cannot read or export its runs. Guest still works independently.

## Tests and verification requirements

Backend `pytest`:
- CSV integrity and airport scope.
- Consistent unit arithmetic: 1 kt = 1000 t; `1000 * 0.10 * 100 km = $10,000` for 1 kt on farm→depot arc.
- Haversine zero and known-distance sanity tests.
- Default scenario mathematical constraints independent from MILP implementation (iterate all sources/facilities/flows and recompute).
- Small-vs-large exclusivity and capacity bounds.
- Yield mass-balance 1050kt input / 210kt SAF output.
- Impossible demand, all facilities disabled, zero/negative/NaN demand, invalid yield and invalid coordinate handling.
- NPV/PVAF at r=0 and r>0, cost decomposition equals objective to numeric tolerance.
- Scenario copy/change yields new input hash and does not mutate prior saved runs.
- Logged-in user cannot access another owner's scenario/run/export; guest session cannot read another's data.
- AI missing-key fallback and malicious AI output rejected or excluded.

Frontend Vitest/Testing Library:
- scenario input validation, cost formatting, solution status and assumption warnings, delta calculations or API response rendering, export action and error handling.

Playwright browser test:
- Open demo, view 80 nodes/four airports via map/list, run solve, verify nonzero cost and facility list, edit airport demand and run again, compare runs, export JSON; test login too if environment permits.

Quality checks:
- Python Ruff, pytest, mypy or equivalent typed checks where configured.
- TypeScript strict mode, ESLint, `tsc --noEmit`, production `next build`.
- `docker compose up --build` works with a seeded Postgres; health checks pass and app serves real data.
- GitHub Actions executes critical checks on PR/push.
- No warnings from missing required environment variables in guest demo; OpenAI key truly optional.
- Add concise script `scripts/smoke_test.sh` or equivalent that runs health, source count and baseline solve and asserts mass balances.

## README and documentation requirements

Write a COMPLETE `README.md` that honestly describes implemented behavior and includes: project name, tagline, problem, target users, features, screenshots section with actual application images if captured, architecture diagram, stack, repo tree, setup prerequisites, installation commands, `.env.example`, running locally, endpoints and request examples, exact input units and assumptions, solver equations/limitations, auth/security, testing, deployment, AI details, demo steps, licences, data provenance and future roadmap. Include `data/DATA_PROVENANCE.md` with OpenFlights ODbL caution, organiser biomass licensing caution, source dates and map attribution. Include a short `docs/DEMO_SCRIPT.md` containing 2-minute and 5-minute demos and Q&A. Do not invent the number of people on the team; use role responsibilities instead. Do not invent a live URL or screenshot.

## Error handling, edge cases and robustness

- Return 422 for negative demand, illegal airport code, yield outside (0,1], discount negative, invalid horizon, duplicate invalid candidates, invalid file imports, NaN/Infinity.
- If required biomass exceeds total 6800kt or maximum permitted refinery throughput, expose reason without attempting impossible solve where detectable.
- If road routing is unavailable, stay in visibly labelled great-circle-proxy mode; never silently claim road routing.
- If a feasible incumbent exists before time limit, store it with relative gap and nonoptimal label; if no feasible incumbent, show proper failure not zero-cost result.
- Handle provider AI errors/timeouts with deterministic narrative; never put unsupported numbers in explanation.
- If all facility sites closed, report infeasibility without crashing.
- If maps cannot load tiles, render the points on a simple in-app canvas with coordinate grid or table fallback.
- If database unavailable, return health failure, show retry UI, and do not substitute hardcoded fake solutions.
- Handle data imports idempotently, with provenance and numeric tolerances.
- Use server-side authorization for every ID based resource, including compare and exports.
- Reject resource exhaustion: limit scenario size, solver time and concurrent solve attempts.

## Deliverables — all required

Create complete working **source code**, frontend, backend, Postgres schema and migrations, authentication, real HiGHS/SciPy MILP, optional real AI integration, deterministic AI fallback, Dockerfiles, Docker Compose, CI/CD workflow, tests, README, data source/provenance docs and clear deploy configuration. Generate no stub files. Prefer simple battle-tested architecture over speculative AI frameworks, real-time telemetry, heavy event infrastructure or unnecessary microservices. Verify all available tests and print their results; when unavailable, report why.

## Final response format after implementation

1. What was built with exact feature completion status.
2. How to start using one command.
3. Which tests, builds and smoke commands actually passed or failed.
4. Known data/model caveats (illustrative demands and yield; distance proxy; unverified site feasibility; unknown OpEx; unknown data redistribution rights).
5. A 2-minute demo instruction sequence, with real UI actions.

**START IMPLEMENTING NOW. Do not merely restate this brief.**
